#! /bin/bash -xe

systemctl start rstudio-connect
