#!/bin/bash -xe

systemctl stop rstudio-connect
